﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using TestCode;
using System.Threading;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        int num1;
        int num2;
        Random rand;
        Calculator calculator = new Calculator();

        [TestInitialize]
        public void Initialize()
        {
            rand = new Random();
            num1 = rand.Next(0,100);
            Thread.Sleep(200);
            num2 = rand.Next(0, 100);
            Thread.Sleep(200);         
            Debug.WriteLine($"Первое число: {num1}");
            Debug.WriteLine($"Второе число: {num2}");

        }

        [TestMethod]
        public void TestMethod1_Sum()
        {
            int rez = calculator.Sum(num1, num2);
            Assert.AreEqual(rez, num1 + num2);
        }

        [TestMethod]
        public void TestGetMethod1_Multiplication()
        {
            int rez = calculator.Multiplication(num1, num2);
            Assert.AreEqual(rez, num1 * num2);
        }

        [TestMethod]
        public void TestGetMethod1_Subtraction()
        {
            double rez = calculator.Subtraction(num1, num2);
            Assert.AreEqual(rez, num1 - num2);
        }

        [TestMethod]
        public void TestGetMethod1_Division()
        {
            double rez = calculator.Division(num1, num2);
            Debug.WriteLine($"результат деления: {rez}");
            Assert.AreEqual(rez, num1 / num2);
       
        }
   
        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void TestDivisionIfDividerIsNull()
        {
      

            if (double.IsInfinity(calculator.Division(num1, num2)))
                throw new DivideByZeroException();
        }

        [TestCleanup]
        public void CleanUp()
        {
           
        }

        
    }
}
