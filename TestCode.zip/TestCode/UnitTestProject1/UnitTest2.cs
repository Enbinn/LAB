﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Person;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Linq;


namespace UnitTestProject1
{
    [TestClass]

    public class UnitTest2
    {
        static List<Person.Person> persons = new List<Person.Person>();
        static Person.Person ConcPerson;
        static Random random = new Random();

        [ClassInitialize]
        public static void Initialize(TestContext context)
        {
            ConcPerson = new Person.Person(1, "MIHAIL", "SHTEPA", false);
            persons.Add(new Person.Person(random.Next(0, 1001), GiveLogin(5).ToString(), GivePassword(8).ToString(), true));
            persons.Add(new Person.Person(random.Next(0, 1001), GiveLogin(5).ToString(), GivePassword(8).ToString(), false));
            persons.Add(new Person.Person(random.Next(0, 1001), GiveLogin(5).ToString(), GivePassword(8).ToString(), true));
            persons.Add(null);
            persons.Add(new Person.Person(random.Next(0, 1001), GiveLogin(5).ToString(), GivePassword(8).ToString(), true));
            persons.Add(new Person.Person(1,"MIHAIL","SHTEPA",false));
            Debug.WriteLine("ID\t\tLOGIN\t\tPASSWORD\t\tBLOCKED\n");
            for (int i = 0; i < persons.Count; i++)
            {
                if (persons[i] != null)
                    Debug.WriteLine($"{persons[i].ID}\t\t{persons[i].LOGIN}\t\t{persons[i].PASSWORD}\t\t{persons[i].BLOCKED}");
                else
                    Debug.WriteLine("NOTHING");
            }
        }

        [ClassCleanup]
        public static void Cleanup()
        {
            persons.Clear();
            random = null;
            ConcPerson = null;
        }
        [TestMethod]
        public void TestMethod1_Unique()
        {
            bool isUnique = persons.Distinct().Count() == persons.Count();
            Assert.IsTrue(isUnique);
        }

        [TestMethod]
        public void TestMethod2_Null()
        {
            bool isNULL = false;
            for (int i = 0; i < persons.Count; i++)
            {
                if (persons[i] == null)
                    isNULL = true;
            }
            Assert.IsFalse(isNULL);
        }

        [TestMethod]
        public void TestMethod3_ConcPolzov()
        {
            bool isConcPersPolzov = false;
            for (int i = 0; i < persons.Count; i++)
            {
                if (persons[i] != null && persons[i].Equals(ConcPerson))
                    isConcPersPolzov = true;
            }
            Assert.IsTrue(isConcPersPolzov);
        }
        static string GiveLogin(int length)
        {
            string alph = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            return new string(Enumerable.Repeat(alph, length).Select(s => s[random.Next(s.Length)]).ToArray());
        }

        static string GivePassword(int length)
        {
            string alph = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            return new string(Enumerable.Repeat(alph, length).Select(s => s[random.Next(s.Length)]).ToArray());
        }

       
    }
}
