﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person
{
    public class Person
    {
        public int ID;
        public string LOGIN;
        public string PASSWORD;
        public bool BLOCKED;
        public Person(int id, string login, string password, bool blocked)
        {
            this.ID = id;
            this.LOGIN = login;
            this.PASSWORD = password;
            this.BLOCKED = blocked;
        }

        public bool Equals(Person other)
        {
            if ((ID == other.ID && LOGIN == other.LOGIN && PASSWORD == other.PASSWORD && BLOCKED == other.BLOCKED))
                return true;
            return false;
        }
    }
}
